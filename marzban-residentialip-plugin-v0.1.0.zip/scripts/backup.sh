#!/usr/bin/env bash
set -euo pipefail
# SQLite online backup avoids copying a database during an active transaction.
DEST="${1:?Usage: scripts/backup.sh /path/to/backup.db}"
docker compose exec -T residential-addon python -c 'import os,sqlite3,base64,tempfile,pathlib;
s=sqlite3.connect(os.environ.get("RESIP_DB","/data/resip.db"));
f=tempfile.NamedTemporaryFile();d=sqlite3.connect(f.name);s.backup(d);d.close();s.close();
print(base64.b64encode(pathlib.Path(f.name).read_bytes()).decode())' | base64 -d > "$DEST"
chmod 600 "$DEST"
echo "Backup written: $DEST"
